# **man pages** #

man pages for MAME and its tools is work of many different contributors, and contain information about usage of MAME and utilities that are coming in package.

Licensed under [CC0 1.0 Universal (CC0 1.0)](https://creativecommons.org/publicdomain/zero/1.0/)
