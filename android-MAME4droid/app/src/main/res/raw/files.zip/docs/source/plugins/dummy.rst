.. _plugins-dummy:

Dummy Test Plugin
=================

This is a sample plugin that shows how to set necessary plugin metadata,
register callbacks, and display a simple menu.  It prints status messages, and
it adds a **Dummy** option to the **Plugin Options** menu.
