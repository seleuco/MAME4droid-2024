.. _plugins-layout:

Layout Plugin
=============

When enabled, the layout plugin allows embedded Lua scripts in layout files to
run.  Built-in artwork for some machines and some external artwork packages can
use Lua scripts to provide enhanced interactive features.  See :ref:`layscript`
for an introduction to layout file scripting.
