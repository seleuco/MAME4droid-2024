.. _plugins-discord:

Discord Presence Plugin
=======================

The Discord presence plugin works with the Discord app for Windows, macOS or
Linux to set your activity to show what you’re doing in MAME.  The activity is
set to *In menu* if you’re using the system or software selection menu,
*Playing* if emulation is running, or *Paused* if emulation is paused.  The
details are set to show the system name and software description if applicable.
