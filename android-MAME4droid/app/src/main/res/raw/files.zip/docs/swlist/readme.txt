Compatibility lists for console/computers in MAME, in CSV format.

File format for a single line is:
<zipname>;<rev_number or MAME version>;<game_flags>;<additional_notes>\n

<game_flags> are in integer format, these are:
0 - Not Tested
1 - Working
2 - Partial
3 - Not Working
