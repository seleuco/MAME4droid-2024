Installing MAME
===============

Microsoft Windows
-----------------

You simply have to download the latest binary archive available from
http://www.mamedev.org and to extract its content to a folder. You will end up
with many files (below you will find explanations about some of these), and in
particular **mame.exe**. This is a command line program. The installation
procedure ends here. Easy, isn’t it?


Other Operating Systems
-----------------------

In this case, you can either look for pre-compiled (SDL)MAME binaries (e.g. in
the repositories of your favorite Linux distro) which should simply extract all
the needed files in a folder you choose, or compile the source code by
yourself. In the latter case, see our section on
:ref:`compiling MAME <compiling-all>`.
