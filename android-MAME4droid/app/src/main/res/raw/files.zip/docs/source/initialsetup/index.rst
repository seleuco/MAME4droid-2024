Getting MAME prepared
---------------------

This section covers initial preparation work needed to use MAME, including
downloading MAME, compiling MAME from source, and configuring MAME.

.. toctree::
	:titlesonly:

	mameintro
	installingmame
	compilingmame
	configuringmame
