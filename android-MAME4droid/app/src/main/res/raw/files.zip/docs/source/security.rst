MAME and security concerns
==========================

MAME is not intended or designed to run in secure sites. It has not been security audited for such types of usage, and has been known in the past to have flaws that could be used for malicious intent if run as administrator or root.

**We do not suggest or condone the use of MAME as administrator or root and use as such is done at your own risk.**

Bug reports, however, are always welcome.
