.. _plugins-console:

Console Plugin
==============

The console plugin provides functionality for MAME’s interactive Lua console.
It is not used directly.  Use the
:ref:`console option <mame-commandline-console>` to activate the interactive Lua
console.  See :ref:`luascript` for more information about MAME’s Lua API.
