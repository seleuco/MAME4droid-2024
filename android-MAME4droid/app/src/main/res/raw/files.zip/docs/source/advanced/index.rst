Advanced configuration
----------------------

.. toctree::
    :titlesonly:

    multiconfig
    paths
    shiftertoggle
    bgfx
    hlsl
    glsl
    ctrlr_config
    devicemap
    linux-lightguns
