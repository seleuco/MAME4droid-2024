# **Artwork** #

Artwork files are representing work of multiple people and are used by layout manager and shaders.

Licensed under [CC0 1.0 Universal (CC0 1.0)](https://creativecommons.org/publicdomain/zero/1.0/)